delete from CustomerManagement.dbo.Customer;

delete from Invoicing.dbo.Invoice;
delete from Invoicing.dbo.Customer;
delete from Invoicing.dbo.MaintenanceJob;

delete from Notification.dbo.Customer;
delete from Notification.dbo.MaintenanceJob;

delete from VehicleManagement.dbo.Vehicle;

delete from WorkshopManagement.dbo.MaintenanceJob;
delete from WorkshopManagement.dbo.Vehicle;
delete from WorkshopManagement.dbo.Customer;

delete from WorkshopManagementEventStore.dbo.WorkshopPlanningEvent;
delete from WorkshopManagementEventStore.dbo.WorkshopPlanning;
