#!/bin/bash
kill $(pgrep kubectl)