namespace AuditlogService
{
    public class AuditlogManagerConfig
    {
        public string LogPath { get; set; }
    }
}