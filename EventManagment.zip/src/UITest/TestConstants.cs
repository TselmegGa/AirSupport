using System;

namespace Pitstop.UITest
{
    public static class TestConstants
    {
        public static Uri PitstopStartUrl => new Uri("http://localhost:7000");
    }
}