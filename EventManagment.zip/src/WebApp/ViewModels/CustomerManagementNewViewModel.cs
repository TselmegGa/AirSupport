﻿using Pitstop.Models;

namespace Pitstop.ViewModels
{
    public class CustomerManagementNewViewModel
    {
        public Customer Customer { get; set; }
    }
}
