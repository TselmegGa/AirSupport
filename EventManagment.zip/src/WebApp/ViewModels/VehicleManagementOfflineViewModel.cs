﻿namespace Pitstop.ViewModels
{
    public class VehicleManagementOfflineViewModel
    {
    }
}
