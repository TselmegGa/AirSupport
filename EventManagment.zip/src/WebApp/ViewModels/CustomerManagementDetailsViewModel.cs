﻿using Pitstop.Models;

namespace Pitstop.ViewModels
{
    public class CustomerManagementDetailsViewModel
    {
        public Customer Customer { get; set; }
    }
}
