﻿namespace Pitstop.ViewModels
{
    public class WorkshopManagementOfflineViewModel
    {
    }
}
