﻿using Pitstop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pitstop.ViewModels
{
    public class VehicleManagementDetailsViewModel
    {
        public Vehicle Vehicle { get; set; }
        public string Owner { get; set; }
    }
}
