﻿namespace Pitstop.ViewModels
{
    public class CustomerManagementOfflineViewModel
    {
    }
}
