namespace CustomerEventHandler
{
    public class CustomerManagerConfig
    {
        public string LogPath { get; set; }
    }
}