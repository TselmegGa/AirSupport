namespace EventManagment
{
    public class EventManagerConfig
    {
        public string LogPath { get; set; }
    }
}